﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EIssue.ViewModel
{
    public class Details
    {
        public string location = "";
        public string Description = "";
        public string category = "";
        public string status = "";
        public string Email = "";
        public string Municipility = "";
       
    }
}
